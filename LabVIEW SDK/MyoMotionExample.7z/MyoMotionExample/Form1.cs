﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;

using System.Timers;
using Easy2AcquireCom;
using System.Threading;
using System.Collections;

namespace MyoMotionExample
{
   

    public partial class Form1 : Form
    {
        // Communications Variables
        private DeviceManager deviceManager = null;
        private IDevice device = null;

        private List<MotionInput> motionInputs;

        // Our sensor-related axes have these orientations 
        //      _______
        //     /       \              X (forward)
        //    |       x |             ↑
        //    |       | |  (left) Y ← .  
        //    |   y__ z |            Z (up)
        //     \_______/  
        //     
        // (this example assumes the head and upper thoracic sensors are placed on the back of patient with 
        //  X pointing up and Y pointing to the patient's left and Z pointing behind the patient.)


        // Our patient-related axes have these orientations
        //      ___
        //     /   \   Y (up)
        //    | o o |  ↑
        //    |  O  |  . → X (left)
        //    \ \_/ / Z (look)
        //     \___/
        //


        // Earth-related coordinate system
        //
        //      ___       Y (North)
        //     /   \      ↑
        //    |     |     . → X (East - the direction of Earth rotation)
        //     \___/     Z (off the ground)
        //

        //  Before pressing Calibrate the patient should be standing or sitting straight up with their head pointing straight forward.  This will be the
        //  zero position for all measurements.
        
        //This example measures cervical joint angles
        private sensor head;                    //head sensor
        private sensor upperthoracic;           //upper thoracic sensor (use of actual sensor is optional)
        private joint cervical;                 //cervical/neck joint
        private quat patient_cal = null;        //orientation of patient (head in this case) in the world.

        private const int headIndex = 0;
        private const int upperthoracicIndex = 1;

        private bool upperthoracic_found = false;

       
        private System.Timers.Timer updateTimer;
        private int updateCounter = 0;
        private String newText = "";
        private bool timerLocked = false;  //used to allow only one timer function to run at a time
        private bool stopFlag = false;     //used to flag the timer function to stop the measurement (ensuring no more Transfers() are called after the measurement has been deactivated.)
        private bool calibrate_clicked = false;  //flag set to true when Calibrate button clicked
        
        public Form1()
        {
            InitializeComponent();

            motionInputs = new List<MotionInput>();

            //create sensors and joint
            head =            new sensor(new vect(0,0,-1), new quat(0,0,0));            //sensor placed on back of head with sensor Z pointing behind patient
            upperthoracic =   new sensor(new vect(0,0,-1), new quat(0,0,0));            //sensor placed on upper back with sensor Z pointing behind patient
            cervical = new joint(upperthoracic, head, new vect(0, -1, 0), new vect(0, 0, 1), new vect(0, -1, 0), new vect(1, 0, 0), new vect(0, 0, 1));


            // Initialize the timer.
            updateTimer = new System.Timers.Timer();
            updateTimer.Enabled = false;
            updateTimer.Interval = 10;
            updateTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
        }

        private MotionInput getMotionInput(String id)
        {
            // Clear the filters.
            device.ClearComponentFilter();

            // Set the filter to get the motion input for the head.
            device.SetComponentFilterTags(id);

            if( device.GetComponentCount() > 0 )
               return (MotionInput)(device.GetComponent(0));
            else
               return null;
        }


        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            { 
                // Do we want to connect?
                if (btnConnect.Text == "Start")
                {
                    // Create a new MyoMotion device manager only once.
                    if( deviceManager == null )
                    {
                        deviceManager = new Easy2AcquireCom.DeviceManager();

                        // Did we get a manager?
                       if (deviceManager != null)
                       {
                           // Yes, then initialize it.
                           deviceManager.Initialize("");
                        }
                                             
                                              
                    }
                    // Did we get a manager?
                    if (deviceManager != null)
                    {
                        deviceManager.ClearLastErrorText();
                        // Set it up.
                        deviceManager.Setup(0);
                        // Get the current device.
                        device = deviceManager.GetCurrentDevice();
                        // Did we get a device?
                        if (device != null)
                        {
                            
                            MotionInput m = getMotionInput("line.human.head");
                            
                            if (m != null)
                              motionInputs.Add(m);
                            else
                            {
                                 textRawData.Text = "Head sensor not found";
                                 return;
                            }
                             
                            m = getMotionInput("line.human.spine.upper");
                             
                            if (m != null)
                            {
                              upperthoracic_found = true;
                              motionInputs.Add(m);
                            }
                            else
                            {
                                 upperthoracic_found = false;
                                 textRawData.Text = "Upper Thoracic sensor not found";
                            }
                              
                            foreach( MotionInput mot in motionInputs )
                            {
                                 // Enable it.
                                 mot.Enable();
                                
                                // Set the frequency.
                                mot.SetDesiredFrequency(100);
                            }
                                
                           // No, then toggle the text.
                           btnConnect.Text = "Stop";

                           //clear cal
                           calibrate_clicked = false;
                           patient_cal = null;

                           //clear stop flag
                           stopFlag = false;

                           // Active it.
                           device.Activate();
         
                           // Start the data transmission.
                           device.Start();

                           // Start the timer.
                           timerLocked = false;
                           updateTimer.Enabled = true;
                                


                            
                        }
                    }
                }
                else
                {
                    // No, then toggle the text.
                    btnConnect.Text = "Start";
                    // Stop the timer.
                    stopFlag = true; 
                                    
                    
                }
            }
            catch (Exception exception)
            {
                // We failed, show a message.
               Console.WriteLine(deviceManager.GetLastErrorText());
               MessageBox.Show(deviceManager.GetLastErrorText());
            }
        }

        private String ds(double v)
        {
            return String.Format("{0:0.000}", v);
        }

        private void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            if( stopFlag )
            {
               updateTimer.Enabled = false;

               // Kill of the device.                
               try
               {
                  // Attempt to stop and deactive the device.
                  calibrate_clicked = false;
                  patient_cal = null;
                  device.Stop();
                  device.Deactivate();
                  foreach (MotionInput m in motionInputs)
                     m.Disable();
                  motionInputs.Clear();
               }
               catch (Exception exception)
               {
                  // We failed, show a message.
                  Console.WriteLine(deviceManager.GetLastErrorText());
                  MessageBox.Show(deviceManager.GetLastErrorText());

               }

               

               return;
            }

            if( timerLocked == true ) return;
            try
            {
               timerLocked = true;
               
                // Get the data.
                int Ret = device.Transfer();
                // Did we get any data?
                if ((Ret & (int)Transfer.TransferDataReady) != 0)
                {
                   int sensorIndex = 0;
                   foreach(MotionInput m in motionInputs )
                   {
                       // Get the number of quants/samples.
                       int quantCount = m.GetQuantCount();

                       // Create an array that is long enought for the 3D data.
                       double[,] quants = new double[3, quantCount];

                       //create object so we can pass ref
                       object _quants = quants;

                       // Get the data from the device.
                       m.GetQuants(0, quantCount, ref _quants, 0);

                       //copy object back to array
                       quants = (double[,])_quants;

                       // For each quant...
                       for (int i = 0; i < quantCount; i++)
                       {
                           // Get the data.
                           quat q = new quat(quants[0,0],quants[1,0],quants[2,0]);

                           switch( sensorIndex )
                           {
                              case headIndex:

                                 if (!head.calibrated && calibrate_clicked)
                                 {
                                    //we will use the head as the calibration orientation of the patient.
                                    
                                    //create earth to patient transformation matrix
                                    vect fwd = head.fwd * q;
                                    matrix _m_earth = new matrix();
                                    _m_earth.y = new vect(0,0,1);
                                    _m_earth.z = new vect(fwd.x, fwd.y, 0).norm();
                                    _m_earth.x = _m_earth.y ^ _m_earth.z;
                                    
                                    //convert transformation matrix to quaternion
                                    patient_cal = new quat();
                                    patient_cal.transform_set(_m_earth);

                                    //calibrate head
                                    head.calibrate(q, patient_cal);
                                 }       

                                 head.set(q);

                                 //if no upper thoracic sensor available, set upper thoracic to the static initial head orientation
                                 if (!upperthoracic_found && !upperthoracic.calibrated && calibrate_clicked && (patient_cal != null))
                                 {
                                    upperthoracic.calibrate(q, patient_cal);
                                    upperthoracic.set(q); 
                                 }
                                 break;

                              case upperthoracicIndex:
                                 if (!upperthoracic.calibrated && calibrate_clicked && (patient_cal != null))
                                    upperthoracic.calibrate(q, patient_cal); //calibrate upper thoracic

                                 upperthoracic.set(q);
                                 break;  
                           }
                           
                       }
                       sensorIndex++;
                     }

                      // Update window at ~30Hz.
                      if (updateCounter++ % 1 == 0)
                      {
                         if( patient_cal != null )
                         {
                            // Copy the data globally.
                            newText = "Cervical Joint Angles: \r\n";
                            newText += "  Axial:   " + ds(cervical.rotation) + "\r\n";
                            newText += "  Flexion: " + ds(cervical.flexion) + "\r\n";
                            newText += "  Lateral: " + ds(cervical.lateral) + "\r\n";
                         }
                         else
                         {
                            newText = "Waiting for calibraiton...";
                         }
                         // Update the data in the UI tread.
                         textRawData.Invoke(new MethodInvoker(UpdateTextHandler));
                      }
                }
            }
            catch (Exception exception)
            {
                // We failed, show a message.
                Console.WriteLine(deviceManager.GetLastErrorText());
                MessageBox.Show(deviceManager.GetLastErrorText());
                timerLocked = false;
            }
            timerLocked = false;
        }
        public void UpdateTextHandler()
        {
            // Copy the data to the textbox.
            textRawData.Text = newText;
        }

        private void calBtn_Click(object sender, EventArgs e)
        {
           calibrate_clicked = true;
        }
    }

  

    public class sensor
    {
      private quat _q0;
      private quat _q;
      private quat _q_orientation_sensor;
      private bool _calibrated;
      private vect _fwd;
      private quat _sensor_orientation;

      public sensor(vect fwd, quat sensor_orientation)
      {
         _sensor_orientation = sensor_orientation;
         _q0 = new quat();
         _q = new quat();
         _fwd = fwd;
         _calibrated = false;         
      }

      public void calibrate(quat qcal, quat q_patient)
      {
         //set quaternion to transform coordinate space and correct heading
         _q_orientation_sensor = _sensor_orientation * q_patient;

         //set calibration quaternion
         _q0 = _q_orientation_sensor * ~qcal;

         _calibrated = true;
      }

      public void set(quat qnew)
      {
         _q = qnew;
      }

      //calibrated q
      public quat q
      {
         get { return _q0 * _q; }
      }

      public quat cal
      {
         get { return _q0; }
      }

      public bool calibrated
      {
         get { return _calibrated; }
      }

      public vect fwd
      {
         get { return _fwd; }
      }
    }

    public class joint
    {
       private rotation _rot;
       private altitude _flex;
       private roll _roll;

       private sensor _base;
       private sensor _dyn;

       public joint(sensor base_sensor, sensor dynamic_sensor, vect rot_around, vect alt_from, vect alt_up, vect roll_from, vect roll_around)
       {
            _base = base_sensor;
            _dyn = dynamic_sensor;
            _rot = new rotation(rot_around);
            _flex = new altitude(alt_from, alt_up);
            _roll = new roll(roll_from, roll_around);
       }

       private quat q
       {
         get { return _dyn.q * ~_base.q; } 
       }

       public double rotation
       {
          get { return _rot.get(q); }
       }

       public double flexion
       {
          get { return _flex.get(q); }
       }

       public double lateral
       {
          get { return _roll.get(q); }
       }
    }

    public class rotation
    {
       private vect _around, _ortho;
       public rotation(vect around)
       {
          _around = around;
         _ortho = around.ortho();
       }

       public double get(quat src)
       {
            vect ortho_2  = _ortho  * src;
            vect around_1 = _around * src;
            vect ortho_1  = _ortho  * new quat().rotation_set(_around, around_1);
            double val      = ortho_1.angle(ortho_2);

            if ((ortho_1 ^ ortho_2) % around_1 < 0)
	            val = -val;

            return val * (180/Math.PI);
        }
    }

    public class altitude
    {
       private vect _from, _up;
       public altitude(vect from, vect up)
       {
          _from = from;
          _up = up;
       }

       public double get(quat src)
       {
          return 90 - (180/Math.PI)*Math.Acos(_from*src % _up);
       }
    }

    public class roll
    {
       private vect _from, _around;
       public roll(vect from, vect around)
       {
          _from = from;
          _around = around;
       }

       public double get(quat src)
       {
          vect up = _around ^ _from;
          vect around_now = _around * src;
          vect up_now = up * src;
          vect up_pitched = around_now ^ (up ^ around_now);

          double val = (180 / Math.PI) * up_pitched.angle(up_now);

          if ((up_pitched ^ up_now) % around_now < 0)
             val = -val;

          return val;
       }
    }

    public class vect
    {
       private double _x, _y, _z;
       public vect() : this(0, 0, 0) { }
       public vect(double x, double y, double z)
       {
          set(x, y, z);          
       }

       public void set(double x, double y, double z)
       {
          _x = x;
          _y = y;
          _z = z;
       }
       
       public double angle(vect arg) { return Math.Acos((this % arg)/Math.Sqrt((this % this) * (arg % arg))); }

       public vect ortho()
       {
          vect tmp = new vect();

          if (Math.Abs(x) < Math.Abs(y))
             tmp.set(0, z, -y);
          else
             tmp.set(-z, 0, x);

          return tmp;
       }
              
       public static vect operator ^(vect v1, vect v2) //cross product
       {
          return new vect(
            v1.y * v2.z - v2.y * v1.z, v1.z * v2.x - v2.z * v1.x, v1.x * v2.y - v2.x * v1.y
          );
       }
       
       public static double operator %(vect v1, vect v2) //scalar/dot product
       {
            return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
       }

       public static vect operator +(vect v1, vect v2) //add v1 and v2
       {
          return new vect(
            v1.x + v2.x,
            v1.y + v2.y,
            v1.z + v2.z
          );
       }

       public static vect operator -(vect v1, vect v2) //subtract v2 from v1
       {
          return new vect(
            v1.x - v2.x,
            v1.y - v2.y,
            v1.z - v2.z
          );
       }

       public static vect operator -(vect v1) //invert
       {
          return new vect(
            v1.x * -1,
            v1.y * -1,
            v1.z * -1
          );
       }

       public static vect operator *(vect v1, double s) //multiply by scalar
       {
          return new vect(
           v1.x*s, v1.y*s, v1.z*s
          );
       }

       public static vect operator /(vect v1, double s) //divide by scalar
       {
          return new vect(
           v1.x / s, v1.y / s, v1.z / s
          );
       }

       public double size() { return Math.Sqrt(size_sq()); }
       public double size_sq() { return x*x + y*y + z*z; }
       public vect norm() { return this / size(); }

       public static vect operator *(vect v1, quat q1) //transform by quat
       {
          vect s = q1.v ^ v1;
          vect t = q1.v ^ s;

          s *= q1.a;
          s += t;
          s += s; 
          s += v1;

          return s;         
       }

       public double x
       {
          get { return _x; }
          set { _x = value; }
       }
       public double y
       {
          get { return _y; }
          set { _y = value; }
       }
       public double z
       {
          get { return _z; }
          set { _z = value; }
       }
    }

    public class matrix
    {
      public vect x, y, z;      
    }

    public class quat
    {
       private double _x, _y, _z, _a;
       private const double eps = 1e-8;

       public quat() : this(0, 0, 0, 1) { }
       public quat(double x, double y, double z) : this(x, y, z, Math.Sqrt(Math.Max(0, 1 - (x * x + y * y + z * z)))) { } //assumed to be normalized quat so a can be calculated
       public quat(double x, double y, double z, double a)
       {
          _x = x;
          _y = y;
          _z = z;
          _a = a;
       }

       public double size() { return Math.Sqrt(size_sq()); }
       public double size_sq() { return x * x + y * y + z * z + a * a; }
       public quat norm() 
       {
          double d = size();

          if (a < 0)
             d = -d;

          return this / d; 
       }

       public static quat operator *(quat q1, quat q2) //transform q1 by q2
       {
          return new quat(
          q2.a * q1.x + q2.x * q1.a + q2.y * q1.z - q2.z * q1.y,
          q2.a * q1.y - q2.x * q1.z + q2.y * q1.a + q2.z * q1.x,
          q2.a * q1.z + q2.x * q1.y - q2.y * q1.x + q2.z * q1.a,
          q2.a * q1.a - q2.x * q1.x - q2.y * q1.y - q2.z * q1.z
          );
       }

       public void transform_set(matrix m)
       {
         double S = 1 + m.x.x + m.y.y + m.z.z;
         vect v1 = new vect();
         double a1;
         if(S > 1e-8)
         {
	         S   = Math.Sqrt(S) * 2.0;
	         v1.x = ( m.y.z - m.z.y ) / S;
	         v1.y = ( m.z.x - m.x.z ) / S;
	         v1.z = ( m.x.y - m.y.x ) / S;
	         a1   = 0.25 * S;
         }
         else if ( m.x.x > m.y.y && m.x.x > m.z.z )  
         {	// Column 0
	         S   = Math.Sqrt( 1.0 + m.x.x - m.y.y - m.z.z ) * 2;
	         v1.x = 0.25 * S;
	         v1.y = (m.x.y + m.y.x ) / S;
	         v1.z = (m.z.x + m.x.z ) / S;
	         a1   = (m.y.z - m.z.y ) / S;
         } 
         else if ( m.y.y > m.z.z ) 
         {	// Column 1: 
	         S   = Math.Sqrt( 1.0 + m.y.y - m.x.x - m.z.z ) * 2;
	         v1.x = (m.x.y + m.y.x ) / S;
	         v1.y = 0.25 * S;
	         v1.z = (m.y.z + m.z.y ) / S;
	         a1   = (m.z.x - m.x.z ) / S;
         } 
         else 
         {	// Column 2:
	         S   = Math.Sqrt( 1.0 + m.z.z - m.x.x - m.y.y ) * 2;
	         v1.x = (m.z.x + m.x.z ) / S;
	         v1.y = (m.y.z + m.z.y ) / S;
	         v1.z = 0.25 * S;
	         a1   = (m.x.y - m.y.x ) / S;
         }

         x = v1.x;
         y = v1.y;
         z = v1.z;
         a = a1;

         if (a < 0)
         {
            quat q1 = -this;
            x = q1.x;
            y = q1.y;
            z = q1.z;
            a = q1.a;

         }
       }

       public quat rotation_set(vect axis, double angle)
       {
         double c, s;
         s = Math.Sin(angle*0.5);
         c = Math.Cos(angle*0.5);

         vect v = axis * s;
         
         return new quat(v.x, v.y, v.z, c);
       }

       public quat rotation_set(vect from, vect to)
       {
            vect v = new vect(0,0,0);
            double c = from % to;
	
            if (c > 1-eps)
            {
            // e
	            v.x = v.y = v.z = 0; // axis * sin(0)
	            a = 1; // cos(0)
            }
            else if (c < eps-1)
            {
            // rotation by pi, take any any perpendicular vector as this rotation axis
	            v = from.ortho().norm(); // axis * sin(0.5*pi)
	            a = 0; // cos(0.5*pi)
            }
            else
            {
            // we know that sin(w/2) = 0.5*sin(w)/cos(w/2)
	            double t = Math.Sqrt(0.5 * (1+c)); // cos(w/2)

	            a = t; 
	            v = (from ^ to) * (0.5/t);
            }

            return new quat(v.x, v.y, v.z, a);
       }
       public static quat operator ~(quat q1) //conjugate
       {
          return new quat(-1 * q1.x, -1 * q1.y, -1 * q1.z, q1.a);
       }

       public static quat operator -(quat q1) 
       {
          return new quat(-1 * q1.x, -1 * q1.y, -1 * q1.z, -1 * q1.a);
       }

       public static quat operator /(quat q1, double s) //divide by scalar
       {
          return new quat(
           q1.x / s, q1.y / s, q1.z / s, q1.a / s
          );
       }
             

       public vect v
       {
          get { return new vect(_x, _y, _z); } 
          set { _x = value.x; _y = value.y; _z = value.z; }          
       }

       public double x
       {
          get { return _x; }
          set { _x = value; }
       }
       public double y
       {
          get { return _y; }
          set { _y = value; }
       }
       public double z
       {
          get { return _z; }
          set { _z = value; }
       }
       public double a
       {
          get { return _a; }
          set { _a = value; }
       }
    }

}
