﻿namespace MyoMotionExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
         this.btnConnect = new System.Windows.Forms.Button();
         this.textRawData = new System.Windows.Forms.TextBox();
         this.calBtn = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // btnConnect
         // 
         this.btnConnect.Location = new System.Drawing.Point(56, 36);
         this.btnConnect.Margin = new System.Windows.Forms.Padding(2);
         this.btnConnect.Name = "btnConnect";
         this.btnConnect.Size = new System.Drawing.Size(87, 35);
         this.btnConnect.TabIndex = 0;
         this.btnConnect.Text = "Start";
         this.btnConnect.UseVisualStyleBackColor = true;
         this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
         // 
         // textRawData
         // 
         this.textRawData.Location = new System.Drawing.Point(56, 90);
         this.textRawData.Margin = new System.Windows.Forms.Padding(2);
         this.textRawData.Multiline = true;
         this.textRawData.Name = "textRawData";
         this.textRawData.Size = new System.Drawing.Size(196, 108);
         this.textRawData.TabIndex = 1;
         // 
         // calBtn
         // 
         this.calBtn.Location = new System.Drawing.Point(165, 36);
         this.calBtn.Name = "calBtn";
         this.calBtn.Size = new System.Drawing.Size(87, 35);
         this.calBtn.TabIndex = 2;
         this.calBtn.Text = "Calibrate";
         this.calBtn.UseVisualStyleBackColor = true;
         this.calBtn.Click += new System.EventHandler(this.calBtn_Click);
         // 
         // Form1
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(303, 248);
         this.Controls.Add(this.calBtn);
         this.Controls.Add(this.textRawData);
         this.Controls.Add(this.btnConnect);
         this.Margin = new System.Windows.Forms.Padding(2);
         this.Name = "Form1";
         this.Text = "Cervical Angles";
         this.ResumeLayout(false);
         this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox textRawData;
        private System.Windows.Forms.Button calBtn;
    }
}

